# Deliverables checklist (ES 678, due 17 November 2026, 11:59 PM IST)

Legend: ✅ done and included in this repository, ☐ an action only you can do.

## A. What the submission page requires

| Requirement | Status | Where |
|---|---|---|
| One PDF, four pages including references, 5 MB or less | ✅ | `paper/es678_project.pdf` (4 pages, about 0.17 MB) |
| Written in the ES 678 LaTeX template, layout unchanged (single column, letter size, margins and fonts as supplied) | ✅ | `paper/es678_project.tex` + unmodified `paper/neurips_2026.sty` |
| LaTeX source files and bibliography | ✅ | `paper/es678_project.tex` (bibliography is its `thebibliography` block), `paper/tables/`, `paper/figures/` |
| Code | ✅ | `src/`, `scripts/`, `tests/`, `notebooks/air_quality_colab.ipynb` |
| README with setup / rebuild steps, code location, data access instructions | ✅ | `README.md`, `data/README.md` |
| Reproducibility notes (data, split, preprocessing, model steps, seeds, versions) | ✅ | `README.md` (design decisions), `results/run_summary.json` |
| AI-use disclosure | ✅ | `AI_DISCLOSURE.md` and Section 8 of the paper |
| Citations for external material or code | ✅ | reference list in the paper; data and software credited in `README.md` |
| No private data, credentials or API keys | ✅ | none are used; the data file is git-ignored; repository scanned for key-like strings |
| Data access instructions or a permitted sample | ✅ | `data/README.md` (instructions; the file is not redistributed) |
| Repository URL accessible to the instructor and graders | ☐ | push to GitHub and make it public (or add the instructor) |
| Paste the repository URL, upload the PDF, tick the confirmation box, press Submit | ☐ | course portal, before the deadline |

## B. What the proposal promised, and where it was delivered

| Proposal commitment | Delivered in |
|---|---|
| Predict next-day PM2.5 per city, beat persistence; AQI not used | `src/aq_pipeline.py` (`build_features`), paper Sections 1-2 |
| CPCB / Kaggle `city_day.csv`, 26 cities, about 29,500 rows; data-quality checks (missing per column and city, duplicates, gaps, extremes, years without PM2.5); drop sparse cities and say so | `audit()`, `results/audit_*.csv`, paper Section 2 (17 cities kept, 9 dropped and named) |
| Features: today's pollutants, PM2.5 lags 1-7, rolling means, month, weekday, city | `FEATURE_SETS["lags 1-7"]` |
| Baselines: persistence and city-month mean (training data only) | `persistence()`, `city_month_fit()` |
| Methods: ridge, random forest, gradient boosting, tuned on validation only | `GRIDS`, `tune()`, `results/tuning_*.csv` |
| Chronological split 2015-18 / 2019 / 2020, test touched once; rolling-origin validation inside training | `split()`, `run_all.py` sections 2-4, `results/rolling_origin.csv` |
| Learned preprocessing fit on training only; lag and rolling features use only the past | `build_pipe()`, `select_numeric()`, `tests/test_leakage.py` |
| Metrics: MAE, RMSE, MAE on top-10% days; per-city results; bootstrap uncertainty | `metrics()`, `block_bootstrap()`, `results/test_metrics_*.csv`, `results/per_city_test.csv` |
| 2020 reported with and without lockdown months, discussed as distribution shift | `results/test_metrics_pre_lockdown.csv`, `..._lockdown.csv`, paper Section 5 |
| Depth 1: lag-feature ablation (none / 1-3 / 1-7) | `results/ablation_lags.csv`, paper Table 2 |
| Depth 2: failure-mode audit on high-pollution days and winter episodes (peak under-prediction) | `results/failure_audit_*.csv`, paper Figure 1 and Section 6 |
| Depth 3: prediction intervals (quantile gradient boosting and split-conformal), coverage by year and in the lockdown | `results/interval_coverage.csv`, `paper/figures/fig_coverage.png`, paper Table 3 |
| Tools: python, pandas, NumPy, scikit-learn, matplotlib, Jupyter, LaTeX | all used |

## C. Rubric (100 points) and the evidence for each line

| Criterion | Points | Evidence |
|---|---|---|
| Problem formulation and scope | 10 | paper Section 1: precise question, row and target defined, prediction time, limits of the claim |
| Data understanding | 10 | paper Section 2, `results/audit_*.csv` |
| Preprocessing and statistical reasoning | 10 | paper Section 2, leakage tests, block bootstrap |
| Baseline and method selection | 15 | paper Sections 3 and 5 (two baselines, three models, objectives and assumptions stated) |
| Evaluation design and metrics | 20 | paper Section 4: chronological split, tuning separate from test, metrics justified, rolling-origin check |
| Results, errors and limitations | 10 | paper Sections 5-7: honest tie with persistence, error audit, uncertainty, limitations |
| Reproducibility and technical integrity | 5 | this repository, tests, `verify_headline.py`, no secrets |
| LaTeX paper and scientific communication | 5 | four pages, template unchanged |
| Graduate depth analysis | 10 | paper Section 6 (three analyses) |
| Individual understanding and defence (viva) | 5 | `VIVA_NOTES.md`; you must be able to explain the work yourself |

## D. Things only you can do before submitting

1. ☐ Replace `YOUR-USERNAME` with your GitHub user name in `paper/es678_project.tex`, `README.md` and
   `notebooks/air_quality_colab.ipynb` (the Colab link), then recompile the paper and confirm it is still 4 pages:
   `grep -rl YOUR-USERNAME . ` lists the files; `sed -i 's/YOUR-USERNAME/<your-name>/g' <file>` replaces it.
2. ☐ Read the paper and `VIVA_NOTES.md` end to end and make sure you can explain every choice and number.
3. ☐ Run `python tests/test_leakage.py` and `python scripts/verify_headline.py` yourself.
4. ☐ Check that `AI_DISCLOSURE.md` and Section 8 of the paper describe *your* actual use of AI tools accurately.
5. ☐ `git init`, commit, push to a public repository, open it in a private window to confirm it loads.
6. ☐ Submit on the portal (you can replace the submission until the deadline).
