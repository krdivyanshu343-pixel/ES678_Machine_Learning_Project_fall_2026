# Viva notes: decisions and likely questions

**One-sentence summary.** I tested whether learned models beat "tomorrow = today" for next-day city PM2.5 in India
using a strict chronological evaluation; they do not, by a meaningful margin, and I analysed where and why.

## Key decisions and the reason for each
* **Chronological split (2015-18 / 2019 / 2020).** Air quality is a time series; a random split would let the model
  train on days after the ones it is tested on, and neighbouring days are nearly copies of each other.
* **Split by target date.** A row dated 31 Dec 2018 has a target on 1 Jan 2019, so it belongs to validation.
* **Persistence as the main baseline.** PM2.5 is strongly autocorrelated; a model must beat it to be useful.
* **Learned preprocessing fit on training only.** Medians, scaling, one-hot categories and the missingness rule
  come from 2015-2018, otherwise validation and test information leaks into the features.
* **Past-only forward fill, lags, trailing means.** Day-*t* features may not look at day *t+1* or later.
* **AQI excluded.** It is computed from the same pollutants, so it is circular and partly encodes the future.
* **Rows need PM2.5 on days *t* and *t+1*.** So persistence exists and all methods use identical rows.
* **MAE as primary metric; RMSE and high-day MAE as secondary.** MAE is robust and in original units; RMSE penalises
  big misses; high days matter most for alerts.
* **Skill score against persistence.** Accuracy alone is meaningless without a baseline (the rubric says so).
* **Block bootstrap.** Days are correlated, so a plain bootstrap would give intervals that are too narrow.
* **Dropped 9 cities.** No usable PM2.5 in training years (rule fixed from training data: at least 200 rows).

## Headline numbers to remember
Persistence MAE 11.03; random forest 10.98 (skill +0.004, CI [-0.018, +0.030]) so a tie. Ridge is worse (-0.099).
City-month mean fails (MAE 34.8) because 2020 levels are far below earlier years. Forest skill by fold: +0.046
(2017), +0.007 (2018), +0.018 (2019), +0.004 (2020 test). Beats persistence in 10 of 17 test cities.
Lag ablation (forest MAE): today only 12.1, lags 1-3 11.4, lags 1-7 11.0. High days: 38 in test; forest
under-predicts 71% of them (bias -28.6). Conformal coverage 0.93 overall but 0.45 on high days; quantile boosting
0.87 overall, 0.74 on high days.

## Likely questions
* *Why not a random split?* Leakage through temporal neighbours; it would overstate accuracy.
* *Why does "today only" lose to persistence?* Squared-loss models shrink predictions toward the mean, while
  persistence copies today's value; with strong autocorrelation copying is hard to beat.
* *Why is conformal coverage 0.98 in lockdown and 0.88 before?* Calibration residuals come from 2019, which includes
  winter; lockdown errors are much smaller, so the fixed-width interval is too wide there and too narrow on peaks.
  Split-conformal assumes exchangeability, which a time series violates.
* *Why does conformal fail on high days?* Its half-width is constant (about 31); peak errors are far larger.
* *Why do all models under-predict high days?* Partly mechanical (selecting days by a high outcome selects days that
  followed lower values), partly shrinkage from squared loss and few training peaks.
* *What if you change the lag window / use 14 days?* Expect small gains: going from 3 to 7 lags helped by about
  0.4 ug/m3; I did not test longer windows, so say that honestly.
* *What if you used a median (absolute-error) loss?* It might reduce the +3.3 bias and close the MAE gap; I did not
  run it because the test set was already used (adding models after seeing test results would be test snooping).
* *Is the lockdown result evidence of a better model?* No, MAE is lower because pollution levels fell.
* *Causation?* No: this is predictive association only.
* *Limits?* Six-month test, no winter peak, 38 high days, uneven stations, no meteorology.

## A small change you might be asked to reason about
Moving the validation year or changing the city threshold changes which cities are in the study and the tuning
data; the conclusion to defend is that tuning and calibration must never use the test year.
